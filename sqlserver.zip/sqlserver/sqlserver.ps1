﻿#need visual c++ redistributable 2017, microsoft odbc driver 17 for sql server, and sqlcmd utility in that order
#Install-Module -Name CredentialManager

$psCred = Get-StoredCredential -Target "Azure Database Credentials"
$password = $psCred.GetNetworkCredential().Password
$user = $psCred.GetNetworkCredential().UserName

$connectionString= "Data Source=tcp:m365migrations.database.windows.net,1433;Database=CollabDataWarehouse;User Id=$user;Password=$password;"

$dropQuery1 = "TRUNCATE TABLE MACHINEDATA"
Invoke-Sqlcmd -query $dropQuery1 -ConnectionString $connectionString 

$dropQuery2 = "TRUNCATE TABLE SIGNIN"
Invoke-Sqlcmd -query $dropQuery2 -ConnectionString $connectionString 

$dropQuery3 = "TRUNCATE TABLE ACTIVATIONDATA"
Invoke-Sqlcmd -query $dropQuery3 -ConnectionString $connectionString 

bcp MACHINEDATA in $PSScriptRoot\CleanDeviceReport.csv -S tcp:m365migrations.database.windows.net,1433 -d CollabDataWarehouse -U collabwarehouse_rw -P 9KOkjfr1XbXHQCMdNTrJ -q -c -C -t  "," -f $PSScriptRoot\DeviceReport.fmt

bcp ACTIVATIONDATA in $PSScriptRoot\CleanActivationReport.csv -S tcp:m365migrations.database.windows.net,1433 -d CollabDataWarehouse -U collabwarehouse_rw -P 9KOkjfr1XbXHQCMdNTrJ -q -c -C -t  "," -f $PSScriptRoot\ActivationData.fmt

bcp SIGNIN in $PSScriptRoot\CleanSignInReport.csv -S tcp:m365migrations.database.windows.net,1433 -d CollabDataWarehouse -U collabwarehouse_rw -P 9KOkjfr1XbXHQCMdNTrJ -q -c -C -t  "," -f $PSScriptRoot\signin.fmt



$joinQuery = "SELECT ACTIVATIONDATA.userPrincipalName, ACTIVATIONDATA.displayName, ACTIVATIONDATA.productType, ACTIVATIONDATA.lastActivatedDate, ACTIVATIONDATA.windows, ACTIVATIONDATA.mac, ACTIVATIONDATA.windows10Mobile, ACTIVATIONDATA.ios, ACTIVATIONDATA.android, ACTIVATIONDATA.activatedOnSharedComputer, ACTIVATIONDATA.Activated, ACTIVATIONDATA.RedundantE3License, SIGNIN.lastSignInDateTime, MACHINEDATA.Computer_Name, tblCore.FunctionDescription, licensed_PWA_users_o365_20201210104946._SKUs_, licensed_PWA_users_o365_20201210104946._licenseCount_  FROM ACTIVATIONDATA INNER JOIN MACHINEDATA ON ACTIVATIONDATA.userPrincipalName = MACHINEDATA.E_Mail_Address inner JOIN SIGNIN ON SIGNIN.userPrincipalName = MACHINEDATA.E_Mail_Address inner JOIN TBLCORE ON TBLCORE.PrimaryEmail = SIGNIN.userPrincipalName inner JOIN licensed_PWA_users_o365_20201210104946 ON licensed_PWA_users_o365_20201210104946._upn_ = TBLCORE.PrimaryEmail "
Invoke-Sqlcmd -query $joinQuery -ConnectionString $connectionString | Export-Csv $PSScriptRoot\fullReport.csv

#need SQLSERVER module Install-Module -Name SqlServer -RequiredVersion 21.1.18256
