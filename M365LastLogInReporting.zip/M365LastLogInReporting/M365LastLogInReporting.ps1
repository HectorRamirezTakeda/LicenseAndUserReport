[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12		#needed for Okta TLS1.2

$global:oauthTokenStartDate = $null
$global:oauthTokenEndDate = $null
$global:headerParams = $null

function FriendlyErrorString ($thisError) {
    [string] $Return = $thisError.Exception
    $Return += "`r`n"
    $Return += "At line:" + $thisError.InvocationInfo.ScriptLineNumber
    $Return += " char:" + $thisError.InvocationInfo.OffsetInLine
    $Return += " For: " + $thisError.InvocationInfo.Line
    Return $Return
}


function ExecuteQueryWithIncrementalRetry($requestUrl, $retryCount, $delay)
{
    if ($retryCount -eq $null) { $retryCount = 5 } # default to 5
    if ($delay -eq $null) { $delay = 500 } # default to 500
    $retryAttempts = 0
    $backoffInterval = $delay
    if ($retryCount -le 0)
    {
        throw New-Object ArgumentException("Provide a retry count greater than zero.")
    }

    if ($delay -le 0)
    {
        throw New-Object ArgumentException("Provide a delay greater than zero.")
    }

    # Do while retry attempt is less than retry count
    while ($retryAttempts -lt $retryCount)
    {
        try
        {
            Invoke-WebRequest -UseBasicParsing -Headers $global:headerParams -Uri $requestUrl -UserAgent $userAgent
            return
        }
        catch [System.Net.WebException]
        {
            $response = [System.Net.HttpWebResponse]$_.Exception.Response
            # Check if request was throttled - http status code 429
            # Check is request failed due to server unavailable - http status code 503
            if ($response -ne $null -and ($response.StatusCode -eq 429 -or $response.StatusCode -eq 503))
            {
                # Output status to console. Should be changed as Debug.WriteLine for production usage.
                Write-Host "CSOM request frequency exceeded usage limits. Sleeping for $backoffInterval seconds before retrying."

                # Add delay for retry
                Start-Sleep -m $backoffInterval

                # Add to retry count and increase delay.
                $retryAttempts++
                $backoffInterval = $backoffInterval * 2
            }
            else
            {
                throw
            }
        }
    }
    throw New-Object Exception("Maximum retry attempts $retryCount, has be attempted.")
}

function getOffice365ActivationsUserDetail($period,$headerParams) 
{	
	$groups = @()

    $outFile = "{0}_getOffice365ActivationsUserDetail_{2}_{1}.csv" -f $(Get-Date -format "yyyyMMddhhmm"),$period,$tenantdomain
    $outFile2 = "{0}_getOffice365ActivationsUserDetail2_{2}_{1}.csv" -f $(Get-Date -format "yyyyMMddhhmm"),$period,$tenantdomain
    $outFile3 = "{0}_MostRecentData_{2}_{1}.csv" -f $(Get-Date -format "yyyyMMddhhmm"),$period,$tenantdomain
    $url = "https://graph.microsoft.com/beta/users?`$top=999&`$select=displayName,userPrincipalName,mail,assignedLicenses,signInActivity"

	do {

		Write-Output "Fetching data using Uri: $url"
        $myReport = ExecuteQueryWithIncrementalRetry $url
		$reportData = $myReport.Content | ConvertFrom-Json
		
		$reportData.value | % {
			$groups += (New-Object PSObject -Property @{
                "userPrincipalName" = $_.userPrincipalName
                "displayName"= $_.displayName
                "lastSignInDateTime"=([string]$_.signInActivity.lastSignInDateTime).split("T")[0]
			})
		} 
		
		
		$url = $reportData.'@odata.nextLink'
		Start-Sleep -seconds 2

        #$cleanGroups = $groups | Select *, @{Name="lastActivatedDate"; Expression = {$_."userActivationCounts".lastActivatedDate}}


        #$cleanCounts = $reportData.value | % {$_.userActivationCounts}
        #$cleanUsers = $reportData.value | % {$_.displayName}

       # $cleanGroup = $cleanGroups | %{
        
 
    } while($url -ne $null)	

   $dir = $PSScriptRoot
   Write-Host $dir

    $groups | Select-Object *| Export-CSV -NoType -Force "$PSScriptRoot\signInTimes.csv"
    return $groups
}






function getOAuthToken()
{
	write-host "getting OAuth Token"	

	$ClientID       = "aa6a2fa8-c32b-4c81-9da0-5920c4e8ade3"
	$ClientSecret   = "_-mxaj4Ubw1k2_PdZh42CZC8ZJ~zxH3sEO"
	$tenantdomain   = "mytakeda"

	$loginURL       = "https://login.microsoftonline.com/"
	$daterange            # For example, contoso.onmicrosoft.com
	$userAgent = "NONISV|Takeda|CollabTeamReporting API application/1.0"

	$body       = @{grant_type="client_credentials";client_id=$ClientID;client_secret=$ClientSecret;scope="https://graph.microsoft.com/.default"}
	$oauth      = Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/57fdf63b-7e22-45a3-83dc-d37003163aae/oauth2/v2.0/token" -Body $body

	if ($oauth.access_token -ne $null) 
	{
		try {            
			$global:headerParams = @{'Authorization'="$($oauth.token_type) $($oauth.access_token)"}		
			write-host "got new OAuth Token"
		
			$global:oauthTokenStartDate = $(Get-Date)
			$global:oauthTokenEndDate = $global:oauthTokenStartDate.AddSeconds($oauth.expires_in)
			write-host $("OAuth Token valid until {0}" -f $global:oauthTokenEndDate)
		} catch {          
			[string] $ErrorString = FriendlyErrorString $_
			write-host $ErrorString

			$global:headerParams = $null
		}
	}
	else
	{
		Write-Host "ERROR: No Access Token"
	}

	#return $headerParams
}



try {            

	$period = "D180"	   

	getOAuthToken		
	
	getOffice365ActivationsUserDetail $period $headerParams

} catch {          
	[string] $ErrorString = FriendlyErrorString $_
	$ErrorString
}
Start-Sleep -Seconds 2