﻿$deviceCSV = import-csv $PSScriptRoot\DeviceReport.csv

#$firstLastName = $deviceCSV | Select-Object *, @{Name="FullName"; Expression = {if($_."Full_Name".contains(",")){$_."Full_Name".Split(",")[1].trim('"').trim(" ") + " " + $_."Full_Name".Split(",")[0].trim('"')}
#else{$_."Full_Name"}}}

$cleanCSV = ForEach ($person in $deviceCSV) {
    if($person."Full_Name".contains(",")){
       $person."Full_Name" = $person."Full_Name".Split(",")[1].trim('"').trim(" ") + " " + $person."Full_Name".Split(",")[0].trim('"')
    }

    $person."IP_Addresses" = $person."IP_Addresses".replace(",", "; ")
    $person."MAC_Addresses" = $person."MAC_Addresses".replace(",", "; ")

    $person
}

$cleanerCSV = $cleanCSV |Sort-Object @{Expression={[string]$_."E_Mail_Address"}; Descending=$false }, @{Expression={[DateTime]$_."Last_Active"};Descending=$true} | select *

$cleanDeviceCSV =   for ($i=1; $i -le $cleanerCSV.length -1; $i++)  {
                  if ($cleanerCSV[$i]."E_Mail_Address" -eq $cleanerCSV[$i-1]."E_Mail_Address"){
                      continue
                  }
                  else {$cleanerCSV[$i]}

                  

               }
  

$cleanDeviceCSV | Select-Object * | ? {$_."E_Mail_Address" -ne "" -and $_."Manufacturer" -ne "Amazon" }| Export-CSV -NoType -Force "$PSScriptRoot\CleanDeviceReport.csv"

#cleaning signin for sql

$signInCSV = import-csv $PSScriptRoot\signInTimes.csv

$cleanSignInCSV = ForEach($account in $signInCSV){
    if($account."displayName".contains(",")){
       $account."displayName" = $account."displayName".Split(",")[1].trim('"').trim(" ") + " " + $account."displayName".Split(",")[0].trim('"')
    }

    $account
}

$cleanSignInCSV | Select-Object *| Export-CSV -NoType -Force "$PSScriptRoot\CleanSignInReport.csv"

#Cleaning activation data for sql

$activationCSV = import-csv $PSScriptRoot\mostRecentAllReportCloud.csv

$cleanActivatioCSV = ForEach($account in $activationCSV){
    if($account."displayName".contains(",")){
       $account."displayName" = $account."displayName".Split(",")[1].trim('"').trim(" ") + " " + $account."displayName".Split(",")[0].trim('"')
    }

    $account
}

$cleanActivatioCSV | Select-Object *| Export-CSV -NoType -Force "$PSScriptRoot\CleanActivationReport.csv"




