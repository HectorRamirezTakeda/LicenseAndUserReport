﻿$logmessage = "Report began at: " + (Get-Date).tostring() + " "

$scriptList = @(
    "$PSScriptRoot\M365UsageReportingCloud.ps1"
    "$PSScriptRoot\M365LastLogInReporting.ps1"
    "$PSScriptRoot\ReportCleaner.ps1"
    "$PSScriptRoot\sqlserver.ps1"
);

foreach ($script in $scriptList) {
    $logmessage += "$script ran at: " + (Get-Date).tostring() + " "
    & $script
   
}

#$signInTimesCSV = Import-Csv C:\Users\spmigration\Documents\signInTimes.csv
#$mostRecentAllReportCSV = Import-Csv C:\Users\spmigration\Documents\mostRecentRedundantReportCloud.csv
#$deviceReportCSV = Import-csv C:\Users\spmigration\Documents\DeviceReport.csv


$logfilepath="$PSScriptRoot\Log.txt"
$logmessage += "Report ended at:  " + (Get-Date).tostring()
Set-Content $logfilepath $logmessage